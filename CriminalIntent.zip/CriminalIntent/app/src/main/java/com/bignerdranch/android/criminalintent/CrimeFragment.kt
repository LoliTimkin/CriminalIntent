package com.bignerdranch.android.criminalintent

import androidx.fragment.app.Fragment


class CrimeFragment: Fragment() {
}